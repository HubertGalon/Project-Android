package com.example.filmwatch.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
